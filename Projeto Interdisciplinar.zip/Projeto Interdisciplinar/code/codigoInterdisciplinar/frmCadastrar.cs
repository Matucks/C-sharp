﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace codigoInterdisciplinar
{
    public partial class frmCadastrar : Form
    {
        public frmCadastrar()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            text_codigo_produto.Text = "";
            text_nome_produto.Text = "";
            textB_categoria_produto.Text = "";
            MessageBox.Show("cadastro feito com sucesso");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            text_codigo_produto.Text = "";
            text_nome_produto.Text = "";
            textB_categoria_produto.Text = "";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
