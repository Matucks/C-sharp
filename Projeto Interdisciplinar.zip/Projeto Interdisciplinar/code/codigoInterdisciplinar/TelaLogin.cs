﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace codigoInterdisciplinar
{
    public partial class TelaLogin : Form
    {
        public TelaLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txt_usuario.Text == "" && txt_senha.Text == "")
            {
                MessageBox.Show("Digite as credenciais corretamente");
            }
            else
            {
                new TelaInterativa().Show();
                this.Hide();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txt_senha.Text = "";
            txt_usuario.Text = "";
            txt_usuario.Focus();
        }

        private void checkBox_mostrar_senha_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_mostrar_senha.Checked)
            {
                txt_senha.PasswordChar = '\0';
            }
            else
            {
                txt_senha.PasswordChar = '•';
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            new frmRegistro().Show();
            this.Hide();
        }

        private void TelaLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
