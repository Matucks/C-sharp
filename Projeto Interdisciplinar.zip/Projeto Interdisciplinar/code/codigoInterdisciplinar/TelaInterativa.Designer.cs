﻿
namespace codigoInterdisciplinar
{
    partial class TelaInterativa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlNav = new System.Windows.Forms.Panel();
            this.btn_carrinho = new System.Windows.Forms.Button();
            this.btn_cadastrar = new System.Windows.Forms.Button();
            this.btn_doces = new System.Windows.Forms.Button();
            this.btn_salgados = new System.Windows.Forms.Button();
            this.btn_paes = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbltitle = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pnlFormLoader = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Sienna;
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pnlNav);
            this.panel1.Controls.Add(this.btn_carrinho);
            this.panel1.Controls.Add(this.btn_cadastrar);
            this.panel1.Controls.Add(this.btn_doces);
            this.panel1.Controls.Add(this.btn_salgados);
            this.panel1.Controls.Add(this.btn_paes);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(279, 793);
            this.panel1.TabIndex = 0;
            // 
            // pnlNav
            // 
            this.pnlNav.BackColor = System.Drawing.Color.MistyRose;
            this.pnlNav.Location = new System.Drawing.Point(0, 297);
            this.pnlNav.Name = "pnlNav";
            this.pnlNav.Size = new System.Drawing.Size(4, 154);
            this.pnlNav.TabIndex = 0;
            // 
            // btn_carrinho
            // 
            this.btn_carrinho.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_carrinho.FlatAppearance.BorderSize = 0;
            this.btn_carrinho.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_carrinho.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_carrinho.ForeColor = System.Drawing.Color.MistyRose;
            this.btn_carrinho.Location = new System.Drawing.Point(0, 432);
            this.btn_carrinho.Name = "btn_carrinho";
            this.btn_carrinho.Size = new System.Drawing.Size(279, 65);
            this.btn_carrinho.TabIndex = 2;
            this.btn_carrinho.Text = "Carrinho        ";
            this.btn_carrinho.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_carrinho.UseVisualStyleBackColor = true;
            this.btn_carrinho.Click += new System.EventHandler(this.btn_carrinho_Click);
            this.btn_carrinho.Leave += new System.EventHandler(this.btn_carrinho_Leave);
            // 
            // btn_cadastrar
            // 
            this.btn_cadastrar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btn_cadastrar.FlatAppearance.BorderSize = 0;
            this.btn_cadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cadastrar.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_cadastrar.ForeColor = System.Drawing.Color.MistyRose;
            this.btn_cadastrar.Location = new System.Drawing.Point(0, 728);
            this.btn_cadastrar.Name = "btn_cadastrar";
            this.btn_cadastrar.Size = new System.Drawing.Size(279, 65);
            this.btn_cadastrar.TabIndex = 2;
            this.btn_cadastrar.Text = "Cadastrar Produto";
            this.btn_cadastrar.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_cadastrar.UseVisualStyleBackColor = true;
            this.btn_cadastrar.Click += new System.EventHandler(this.button5_Click);
            this.btn_cadastrar.Leave += new System.EventHandler(this.btn_cadastrar_Leave);
            // 
            // btn_doces
            // 
            this.btn_doces.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_doces.FlatAppearance.BorderSize = 0;
            this.btn_doces.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_doces.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_doces.ForeColor = System.Drawing.Color.MistyRose;
            this.btn_doces.Location = new System.Drawing.Point(0, 367);
            this.btn_doces.Name = "btn_doces";
            this.btn_doces.Size = new System.Drawing.Size(279, 65);
            this.btn_doces.TabIndex = 2;
            this.btn_doces.Text = "Doces            ";
            this.btn_doces.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_doces.UseVisualStyleBackColor = true;
            this.btn_doces.Click += new System.EventHandler(this.btn_doces_Click);
            this.btn_doces.Leave += new System.EventHandler(this.btn_doces_Leave);
            // 
            // btn_salgados
            // 
            this.btn_salgados.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_salgados.FlatAppearance.BorderSize = 0;
            this.btn_salgados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_salgados.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_salgados.ForeColor = System.Drawing.Color.MistyRose;
            this.btn_salgados.Location = new System.Drawing.Point(0, 302);
            this.btn_salgados.Name = "btn_salgados";
            this.btn_salgados.Size = new System.Drawing.Size(279, 65);
            this.btn_salgados.TabIndex = 2;
            this.btn_salgados.Text = "Salgados       ";
            this.btn_salgados.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_salgados.UseVisualStyleBackColor = true;
            this.btn_salgados.Click += new System.EventHandler(this.btn_salgados_Click);
            this.btn_salgados.Leave += new System.EventHandler(this.btn_salgados_Leave);
            // 
            // btn_paes
            // 
            this.btn_paes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_paes.FlatAppearance.BorderSize = 0;
            this.btn_paes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_paes.Font = new System.Drawing.Font("Nirmala UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_paes.ForeColor = System.Drawing.Color.MistyRose;
            this.btn_paes.Location = new System.Drawing.Point(0, 237);
            this.btn_paes.Name = "btn_paes";
            this.btn_paes.Size = new System.Drawing.Size(279, 65);
            this.btn_paes.TabIndex = 2;
            this.btn_paes.Text = "Pães              ";
            this.btn_paes.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btn_paes.UseVisualStyleBackColor = true;
            this.btn_paes.Click += new System.EventHandler(this.button1_Click);
            this.btn_paes.Leave += new System.EventHandler(this.btn_paes_Leave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Sienna;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(279, 237);
            this.panel2.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::codigoInterdisciplinar.Properties.Resources.fodase6;
            this.pictureBox1.Location = new System.Drawing.Point(87, 35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(94, 97);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.DarkSalmon;
            this.label2.Location = new System.Drawing.Point(59, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Usuário cadastrado";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.MistyRose;
            this.label1.Location = new System.Drawing.Point(76, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "TheBakery";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbltitle.ForeColor = System.Drawing.Color.Sienna;
            this.lbltitle.Location = new System.Drawing.Point(296, 35);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(119, 48);
            this.lbltitle.TabIndex = 1;
            this.lbltitle.Text = "Pães";
            // 
            // button6
            // 
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(1264, 45);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(46, 38);
            this.button6.TabIndex = 2;
            this.button6.Text = "X";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Nirmala UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox1.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.textBox1.Location = new System.Drawing.Point(804, 45);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(438, 38);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "Procurando alguma coisa...";
            // 
            // pnlFormLoader
            // 
            this.pnlFormLoader.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlFormLoader.Location = new System.Drawing.Point(279, 153);
            this.pnlFormLoader.Name = "pnlFormLoader";
            this.pnlFormLoader.Size = new System.Drawing.Size(1079, 640);
            this.pnlFormLoader.TabIndex = 4;
            this.pnlFormLoader.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlFormLoader_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::codigoInterdisciplinar.Properties.Resources.doces_colorido;
            this.pictureBox2.Location = new System.Drawing.Point(214, 367);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(65, 65);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::codigoInterdisciplinar.Properties.Resources.pao_colorido;
            this.pictureBox4.Location = new System.Drawing.Point(214, 237);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(65, 65);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::codigoInterdisciplinar.Properties.Resources.croassaint_colorido;
            this.pictureBox3.Location = new System.Drawing.Point(214, 302);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(65, 65);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::codigoInterdisciplinar.Properties.Resources.carrinho7;
            this.pictureBox5.Location = new System.Drawing.Point(214, 432);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(65, 65);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // TelaInterativa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(1358, 793);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbltitle);
            this.Controls.Add(this.pnlFormLoader);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TelaInterativa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TelaInterativa";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_carrinho;
        private System.Windows.Forms.Button btn_cadastrar;
        private System.Windows.Forms.Button btn_doces;
        private System.Windows.Forms.Button btn_salgados;
        private System.Windows.Forms.Button btn_paes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel pnlFormLoader;
        private System.Windows.Forms.Panel pnlNav;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}