﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace codigoInterdisciplinar
{
    public partial class TelaInterativa : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
         (
               int nLeftRect,
               int nTopRect,
               int nRightRect,
               int nBottomRect,
               int nWidthEllipse,
               int nHeightEllipse

         );
        public TelaInterativa()
        {
            InitializeComponent();
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 25, 25));
            pnlNav.Height = btn_paes.Height;
            pnlNav.Top = btn_paes.Top;
            pnlNav.Left = btn_paes.Left;

            lbltitle.Text = "Pães";
            frmPaes frmDashboard_vrb = new frmPaes() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmDashboard_vrb.FormBorderStyle = FormBorderStyle.None;
            this.pnlFormLoader.Controls.Add(frmDashboard_vrb);
            frmDashboard_vrb.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btn_paes.Height;
            pnlNav.Top = btn_paes.Top;
            pnlNav.Left = btn_paes.Left;
            btn_paes.BackColor = Color.FromArgb(160, 82, 45);

            lbltitle.Text = "Pães";
            this.pnlFormLoader.Controls.Clear();
            frmPaes frmDashboard_vrb = new frmPaes() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmDashboard_vrb.FormBorderStyle = FormBorderStyle.None;
            this.pnlFormLoader.Controls.Add(frmDashboard_vrb);
            frmDashboard_vrb.Show();
        }

        private void btn_salgados_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btn_salgados.Height;
            pnlNav.Top = btn_salgados.Top;
            btn_salgados.BackColor = Color.FromArgb(160, 82, 45);

            lbltitle.Text = "Salgados";
            this.pnlFormLoader.Controls.Clear();
            frmSalgados frmAnalytics_vrb = new frmSalgados() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmAnalytics_vrb.FormBorderStyle = FormBorderStyle.None;
            this.pnlFormLoader.Controls.Add(frmAnalytics_vrb);
            frmAnalytics_vrb.Show();
        }

        private void btn_doces_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btn_doces.Height;
            pnlNav.Top = btn_doces.Top;
            btn_doces.BackColor = Color.FromArgb(160, 82, 45);

            this.pnlFormLoader.Controls.Clear();
            frmDoces frmCalender_vrb = new frmDoces() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmCalender_vrb.FormBorderStyle = FormBorderStyle.None;
            this.pnlFormLoader.Controls.Add(frmCalender_vrb);
            frmCalender_vrb.Show();
            lbltitle.Text = "Doces";
        }

        private void btn_carrinho_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btn_carrinho.Height;
            pnlNav.Top = btn_carrinho.Top;
            btn_carrinho.BackColor = Color.FromArgb(160, 82, 45);

            this.pnlFormLoader.Controls.Clear();
            frmCarrinho frmContactUs_vrb = new frmCarrinho() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmContactUs_vrb.FormBorderStyle = FormBorderStyle.None;
            this.pnlFormLoader.Controls.Add(frmContactUs_vrb);
            frmContactUs_vrb.Show();
            lbltitle.Text = "Carrinho";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btn_cadastrar.Height;
            pnlNav.Top = btn_cadastrar.Top;
            btn_cadastrar.BackColor = Color.FromArgb(160, 82, 45);

            this.pnlFormLoader.Controls.Clear();
            frmCadastrar frmSettings_vrb = new frmCadastrar() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            frmSettings_vrb.FormBorderStyle = FormBorderStyle.None;
            this.pnlFormLoader.Controls.Add(frmSettings_vrb);
            frmSettings_vrb.Show();
            lbltitle.Text = "Cadastro de Produtos";
        }

        private void btn_paes_Leave(object sender, EventArgs e)
        {
            btn_paes.BackColor = Color.FromArgb(160, 82, 45);
        }

        private void btn_salgados_Leave(object sender, EventArgs e)
        {
            btn_salgados.BackColor = Color.FromArgb(160, 82, 45);
        }

        private void btn_doces_Leave(object sender, EventArgs e)
        {
            btn_doces.BackColor = Color.FromArgb(160, 82, 45);
        }

        private void btn_carrinho_Leave(object sender, EventArgs e)
        {
            btn_carrinho.BackColor = Color.FromArgb(160, 82, 45);
        }

        private void btn_cadastrar_Leave(object sender, EventArgs e)
        {
            btn_cadastrar.BackColor = Color.FromArgb(160, 82, 45);
        }

        private void pnlFormLoader_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
