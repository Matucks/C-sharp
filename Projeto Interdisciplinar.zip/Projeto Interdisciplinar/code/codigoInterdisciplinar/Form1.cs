﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace codigoInterdisciplinar
{
    public partial class frmRegistro : Form
    {
        public frmRegistro()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = Convert.ToString(txt_usuario.Text);
                string senha = Convert.ToString(txt_senha.Text);

            }
            catch (FormatException)
            {
                MessageBox.Show("erro, valores digitados são incompativeis");
            }
            if (txt_usuario.Text == "" && txt_senha.Text == "" && txt_com_senha.Text == "")
            {
                MessageBox.Show("usuario e senha não foram preenchidos corretamente", "cadastro falhou");
            }
            else if (txt_senha.Text == txt_com_senha.Text)
            {
                MessageBox.Show("sua conta foi craida com sucesso");
            }
            else
            {
                MessageBox.Show("falha ao criar conta, as senhas não são coerentes");
                txt_senha.Text = "";
                txt_com_senha.Text = "";
                txt_senha.Focus();
            }
        }

        private void checkBox_mostrar_senha_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_mostrar_senha.Checked)
            {
                txt_senha.PasswordChar = '\0';
                txt_com_senha.PasswordChar = '\0';
            }
            else
            {
                txt_senha.PasswordChar = '•';
                txt_com_senha.PasswordChar = '•';
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txt_senha.Text = "";
            txt_com_senha.Text = "";
            txt_usuario.Text = "";
            txt_usuario.Focus();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            new TelaLogin().Show();
            this.Hide();
        }

        private void frmRegistro_Load(object sender, EventArgs e)
        {

        }
    }
}

